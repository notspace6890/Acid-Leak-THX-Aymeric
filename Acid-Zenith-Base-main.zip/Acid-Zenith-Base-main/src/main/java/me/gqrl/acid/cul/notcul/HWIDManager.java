package me.gqrl.acid.cul.notcul;

import me.gqrl.acid.cul.notcul.yescul.DisplayUtil;
import me.gqrl.acid.cul.notcul.yescul.NoStackTraceThrowable;
import me.gqrl.acid.cul.notcul.yescul.SystemUtil;
import me.gqrl.acid.cul.notcul.yescul.URLReader;

import java.util.ArrayList;
import java.util.List;

public
class HWIDManager {

    /**
     * Your pastebin URL goes inside the empty string below.
     * It should be a raw pastebin link, for example: pastebin.com/raw/pasteid
     */

    public static final String pastebinURL = "https://gist.githubusercontent.com/kyv3-v3/fa409c2701a4aefee352f0fd91bf9709/raw/6a56fca0985c1c46e89e758a479664c86268dfd5/HWID.txt";
    
    
    public static List <String> hwids = new ArrayList <>();

    public static
    void hwidCheck() {
        hwids = URLReader.readURL();
        boolean isHwidPresent = hwids.contains(SystemUtil.getSystemInfo());
        if (! isHwidPresent) {
            DisplayUtil.Display();
            throw new NoStackTraceThrowable("");
        }
    }
}
