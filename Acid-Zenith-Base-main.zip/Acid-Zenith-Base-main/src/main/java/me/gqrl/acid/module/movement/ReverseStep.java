package me.gqrl.acid.module.movement;

import me.gqrl.acid.module.Category;
import me.gqrl.acid.module.Module;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class ReverseStep extends Module {

   public ReverseStep()
   {
    super("ReverseStep", "", Category.MOVEMENT);
	}

	@SubscribeEvent
	public void onUpdate(final TickEvent.ClientTickEvent event) {
		if(mc.world == null || mc.player.isInWater() || mc.player.isInLava()) return;
		if (mc.player.onGround) {
            mc.player.motionY -= 1.0;
        }
	}
	
}
