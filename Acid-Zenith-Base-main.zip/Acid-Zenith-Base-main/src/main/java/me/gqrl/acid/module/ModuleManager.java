package me.gqrl.acid.module;

import java.util.ArrayList;
import java.util.stream.Collectors;
import me.gqrl.acid.Client;
import me.gqrl.acid.gui.hud.component.*;
import me.gqrl.acid.module.Category;
import me.gqrl.acid.module.Module;
import me.gqrl.acid.module.combat.*;
import me.gqrl.acid.module.exploit.*;
import me.gqrl.acid.module.movement.*;
import me.gqrl.acid.module.render.*;
import me.gqrl.acid.module.misc.*;
import me.gqrl.acid.module.hud.*;

public class ModuleManager {
    private final ArrayList<Module> modules = new ArrayList();

    public ModuleManager() {
//Combat
this.modules.add(new AutoArmor());
//this.modules.add(new AutoLog());
this.modules.add(new BowSpam());
this.modules.add(new AutoTotem());
this.modules.add(new AutoTrap());
this.modules.add(new HoleFiller());
this.modules.add(new PistonCrystal("PistonCrystal", "SIXTIETH's pistonaura", Category.COMBAT));
this.modules.add(new Surround());
//this.modules.add(new ());
//this.modules.add(new ());
//this.modules.add(new ());
//this.modules.add(new ());
//this.modules.add(new ());
//this.modules.add(new ());
//this.modules.add(new ());
//this.modules.add(new ());

//Exploit
this.modules.add(new BoatPlaceBypass("BoatPlaceBypass", "Allows you to place boats outside of water on 2b (dont leave this on)", Category.EXPLOIT));
this.modules.add(new EntityVanish());
this.modules.add(new PacketCanceller("PacketCanceller", "Cancels Packets", Category.EXPLOIT));
this.modules.add(new HasteExploit());
this.modules.add(new PosDesync());
this.modules.add(new DonkeyDupe());
this.modules.add(new BallzDupe());
this.modules.add(new AuthBypass());
//this.modules.add(new ());
//this.modules.add(new ());
//this.modules.add(new ());
//this.modules.add(new ());
//this.modules.add(new ());

//Movement
this.modules.add(new Anchor());
this.modules.add(new AntiVoid());
this.modules.add(new AutoWalk());
//this.modules.add(new FastSwim());
this.modules.add(new LongJump());
this.modules.add(new NoSlow());
this.modules.add(new ReverseStep());
this.modules.add(new Step());
this.modules.add(new Strafe("Strafe", "speeeeeeeed", Category.MOVEMENT));
this.modules.add(new Velocity("Velocity", "yes", Category.MOVEMENT));
//this.modules.add(new ());
//this.modules.add(new ());
//this.modules.add(new ());
//this.modules.add(new ());
//this.modules.add(new ());

//Render
this.modules.add(new BlockHighlight("BlockHighlight", "highlights tge block u lookin at", Category.RENDER));
this.modules.add(new Chams());
this.modules.add(new CustomFont("CustomFont", "Use a custom font render instead of Minecraft's default", Category.RENDER));
this.modules.add(new FullBright("FullBright", "light it up", Category.RENDER));
this.modules.add(new ItemViewmodle());
this.modules.add(new VoidESP());
//this.modules.add(new ());
//this.modules.add(new ());
//this.modules.add(new ());
//this.modules.add(new ());

//Misc
this.modules.add(new Blink());
this.modules.add(new ChatSuffix());
//this.modules.add(new DiscordRPC());
this.modules.add(new FakePlayer());
this.modules.add(new GuiMove());
this.modules.add(new MiddleClick());
//this.modules.add(new ());
//this.modules.add(new ());
//this.modules.add(new ());
//this.modules.add(new ());

//Hud
this.modules.add(new Watermark("Watermark", Category.HUD));
this.modules.add(new ArmorHud());
//this.modules.add(new ());
//this.modules.add(new ());
//this.modules.add(new ());
//this.modules.add(new ());

//Theme
this.modules.add(new ClickGUI("ClickGUI", "Toggle modules by clicking on them", Category.THEME));
this.modules.add(new HUDEditor("HUDEditor", Category.THEME));
//this.modules.add(new ());
//this.modules.add(new ());
//this.modules.add(new ());
//this.modules.add(new ());
    }

    public static void onUpdate() {
        Client.moduleManager.getModules().stream().filter(Module::isEnabled).forEach(Module::onUpdate);
    }

    public ArrayList<Module> getModules() {
        return this.modules;
    }

    public Module getModule(String name) {
        for (Module module : this.modules) {
            if (!module.getName().equalsIgnoreCase(name)) continue;
            return module;
        }
        return null;
    }

    public ArrayList<Module> getModules(Category category) {
        ArrayList<Module> mods = new ArrayList<Module>();
        for (Module module : this.modules) {
            if (!module.getCategory().equals((Object)category)) continue;
            mods.add(module);
        }
        return mods;
    }

    public ArrayList<Module> getEnabledModules() {
        return this.modules.stream().filter(Module::isEnabled).collect(Collectors.toCollection(ArrayList::new));
    }
}
