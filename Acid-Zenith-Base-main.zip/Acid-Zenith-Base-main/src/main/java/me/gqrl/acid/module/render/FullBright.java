package me.gqrl.acid.module.render;

import me.gqrl.acid.module.Category;
import me.gqrl.acid.module.Module;

public class FullBright extends Module {
	
	float old;
	
	public FullBright(String name, String description, Category category)
	{
		super(name, description, category);
	}
	
	@Override
	public void onEnable() {
        old = mc.gameSettings.gammaSetting;
        mc.gameSettings.gammaSetting = 666f;
    }
	
    public void onDisable() {
        mc.gameSettings.gammaSetting = old;
    }

}
