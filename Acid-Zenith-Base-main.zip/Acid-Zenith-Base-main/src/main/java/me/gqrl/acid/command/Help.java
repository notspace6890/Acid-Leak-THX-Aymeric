package me.gqrl.acid.command;

import me.gqrl.acid.Client;
import me.gqrl.acid.command.Command;
import me.gqrl.acid.util.LoggerUtil;

public class Help
extends Command {
    public Help(String name, String[] alias, String usage) {
        super(name, alias, usage);
    }

    @Override
    public void onTrigger(String arguments) {
        LoggerUtil.sendMessage("AcidCore");
        for (Command command : Client.commandManager.getCommands()) {
            LoggerUtil.sendMessage(command.getName() + " - " + command.getUsage());
        }
    }
}
