package me.gqrl.acid.module.movement;

import me.gqrl.acid.module.Category;
import me.gqrl.acid.module.Module;

public class StrafeBypass
extends Module {
    public StrafeBypass(String name, String description, Category category) {
        super(name, description, category);
    }
}
