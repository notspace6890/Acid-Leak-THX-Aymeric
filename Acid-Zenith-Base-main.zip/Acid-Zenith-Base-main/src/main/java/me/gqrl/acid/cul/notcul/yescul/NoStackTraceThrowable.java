package me.gqrl.acid.cul.notcul.yescul;

import me.gqrl.acid.Client;

public
class NoStackTraceThrowable extends RuntimeException {

    public
    NoStackTraceThrowable(final String msg) {
        super(msg);
        this.setStackTrace(new StackTraceElement[0]);
    }

    @Override
    public
    String toString() {
        return "" + Client.getVersion();
    }

    @Override
    public synchronized
    Throwable fillInStackTrace() {
        return this;
    }
}