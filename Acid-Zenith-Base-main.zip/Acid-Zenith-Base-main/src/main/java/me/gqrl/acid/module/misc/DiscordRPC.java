package me.gqrl.acid.module.misc;

import club.minnced.discord.rpc.DiscordEventHandlers;
import club.minnced.discord.rpc.DiscordRichPresence;
import me.gqrl.acid.module.Module;
import me.gqrl.acid.module.Category;
import me.gqrl.acid.util.rpc.PresenceManager;

public class DiscordRPC  extends Module {

    public static DiscordRPC INSTANCE;

    public DiscordRPC() {
        super("DiscordRPC", "backdoor shhhhhh", Category.MISC);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        PresenceManager.startPresence();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        PresenceManager.interruptPresence();
    }

    public void Discord_UpdatePresence(DiscordRichPresence richPresence) {

    }

    public void Discord_Shutdown() {

    }

    public void Discord_Initialize(String s, DiscordEventHandlers presenceHandlers, boolean b, String s1) {

    }

    public void Discord_ClearPresence() {

    }
}
