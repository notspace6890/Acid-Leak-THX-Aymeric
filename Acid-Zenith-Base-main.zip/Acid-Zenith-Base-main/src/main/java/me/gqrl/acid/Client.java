package me.gqrl.acid;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Font;
import me.gqrl.acid.EventHandler;
import me.gqrl.acid.command.CommandManager;
import me.gqrl.acid.config.Config;
import me.gqrl.acid.event.EventManager;
import me.gqrl.acid.gui.clickgui.ClickGUI;
import me.gqrl.acid.gui.hud.HUDEditor;
import me.gqrl.acid.module.ModuleManager;
import me.gqrl.acid.setting.SettingManager;
import me.gqrl.acid.friend.*;
import me.gqrl.acid.util.font.CustomFontRenderer;
import me.gqrl.acid.cul.notcul.HWIDManager;
import net.minecraft.client.Minecraft;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import org.lwjgl.opengl.Display;

@Mod(modid="acid", name="Acid.uwu", version="b1")
public class Client {
    public static final String name = "Acid.uwu";
    public static final String version = "b1";
    public static final String creator = "gqrl/cumhax";
    public static ModuleManager moduleManager;
    public static SettingManager settingManager;
    public static FriendManager friendManager;
    public static CustomFontRenderer customFontRenderer;
    public static ClickGUI clickGUI;
    public static CommandManager commandManager;
    public static final EventManager EVENT_MANAGER;
    public static HUDEditor hudEditor;

    public static void SendMessage(String string) {
        if (Minecraft.getMinecraft().ingameGUI != null || Minecraft.getMinecraft().player == null) {
            Minecraft.getMinecraft().ingameGUI.getChatGUI().printChatMessage(new TextComponentString("\u00a77" + ChatFormatting.BLUE + "[Acid Zenith Base]\u00a7f " + ChatFormatting.RESET + string));
        }
    }
    
    public static
    String getVersion() {
        return getVersion();
    }

    @Mod.EventHandler
    public void initialize(FMLInitializationEvent event) {
        HWIDManager.hwidCheck();
        commandManager = new CommandManager();
        settingManager = new SettingManager();
        moduleManager = new ModuleManager();
        friendManager = new FriendManager();
        customFontRenderer = new CustomFontRenderer(new Font("Verdana", 0, SettingManager.getSetting("CustomFont", "Font Sise").getIntegerValue()), true, false);
        clickGUI = new ClickGUI();
        hudEditor = new HUDEditor();
        Config.loadConfig();
        Display.setTitle("Acid-Zenith-Edition :^]");
        Runtime.getRuntime().addShutdownHook(new Config());
        MinecraftForge.EVENT_BUS.register(new EventHandler());
    }

    static {
        EVENT_MANAGER = new EventManager();
    }
}
