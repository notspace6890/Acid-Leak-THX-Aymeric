package me.gqrl.acid.module.render;

import me.gqrl.acid.Client;
import me.gqrl.acid.module.Category;
import me.gqrl.acid.module.Module;

public class HUDEditor
extends Module {
    public HUDEditor(String name, Category category) {
        super(name, category);
    }

    @Override
    public void onEnable() {
        mc.displayGuiScreen(Client.hudEditor);
    }
}
