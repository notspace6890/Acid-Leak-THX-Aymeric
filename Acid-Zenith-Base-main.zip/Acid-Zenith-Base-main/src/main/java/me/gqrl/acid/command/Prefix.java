package me.gqrl.acid.command;

import me.gqrl.acid.Client;
import me.gqrl.acid.command.Command;
import me.gqrl.acid.util.LoggerUtil;

public class Prefix
extends Command {
    public Prefix(String name, String[] alias, String usage) {
        super(name, alias, usage);
    }

    @Override
    public void onTrigger(String arguments) {
        if (arguments.equals("")) {
            this.printUsage();
            return;
        }
        Client.commandManager.setPrefix(arguments);
        LoggerUtil.sendMessage("Prefix set to " + arguments);
    }
}
