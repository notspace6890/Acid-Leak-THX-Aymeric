package me.gqrl.acid.module.render;

import me.gqrl.acid.module.Category;
import me.gqrl.acid.module.Module;
import me.gqrl.acid.setting.Setting;

public class CustomFont
extends Module {
    public final Setting fontsise = new Setting("Font Sise", this, 20, 14, 30);
    public final Setting yoffset = new Setting("Y-Offset", this, 0, -8, 8);

    public CustomFont(String name, String description, Category category) {
        super(name, description, category);
        this.addSetting(this.fontsise);
        this.addSetting(this.yoffset);
    }

    @Override
    public void onUpdate() {
    }
}
