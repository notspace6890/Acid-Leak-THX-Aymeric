package me.gqrl.acid.setting;

public enum SettingType {
    BOOLEAN,
    INTEGER,
    ENUM;

}
