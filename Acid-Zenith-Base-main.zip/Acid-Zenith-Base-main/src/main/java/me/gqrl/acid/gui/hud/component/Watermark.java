package me.gqrl.acid.gui.hud.component;

import me.gqrl.acid.module.Category;
import me.gqrl.acid.module.Module;
import me.gqrl.acid.setting.Setting;

public class Watermark
extends Module {
    public final Setting X_ = new Setting("X", this, 100, 0, 8000);
    public final Setting Y_ = new Setting("Y", this, 100, 0, 8000);

    public Watermark(String name, Category category) {
        super(name, category);
        this.addSetting(this.X_);
        this.addSetting(this.Y_);
    }
}
