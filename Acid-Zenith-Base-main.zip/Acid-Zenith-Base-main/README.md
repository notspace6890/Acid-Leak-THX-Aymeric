# Acid.uwu

## How to build:
MacOS: 

./gradlew setupDecompWorkspace

./gradlew build



Windows: 

gradlew setupDecompWorkspace

gradlew build

